package f00f.net.irc.martyr;

import java.util.Hashtable;

import f00f.net.irc.martyr.commands.InviteCommand;
import f00f.net.irc.martyr.commands.JoinCommand;
import f00f.net.irc.martyr.commands.KickCommand;
import f00f.net.irc.martyr.commands.MessageCommand;
import f00f.net.irc.martyr.commands.ModeCommand;
import f00f.net.irc.martyr.commands.NickCommand;
import f00f.net.irc.martyr.commands.NoticeCommand;
import f00f.net.irc.martyr.commands.PartCommand;
import f00f.net.irc.martyr.commands.PingCommand;
import f00f.net.irc.martyr.commands.QuitCommand;
import f00f.net.irc.martyr.commands.TopicCommand;
import f00f.net.irc.martyr.commands.WelcomeCommand;
import f00f.net.irc.martyr.errors.ChannelBannedError;
import f00f.net.irc.martyr.errors.ChannelInviteOnlyError;
import f00f.net.irc.martyr.errors.ChannelLimitError;
import f00f.net.irc.martyr.errors.ChannelWrongKeyError;
import f00f.net.irc.martyr.errors.NickInUseError;
import f00f.net.irc.martyr.replies.ChannelCreationReply;
import f00f.net.irc.martyr.replies.LUserClientReply;
import f00f.net.irc.martyr.replies.LUserMeReply;
import f00f.net.irc.martyr.replies.LUserOpReply;
import f00f.net.irc.martyr.replies.ModeReply;
import f00f.net.irc.martyr.replies.NamesEndReply;
import f00f.net.irc.martyr.replies.NamesReply;
import f00f.net.irc.martyr.replies.TopicInfoReply;
import f00f.net.irc.martyr.replies.WhoisChannelsReply;
import f00f.net.irc.martyr.replies.WhoisEndReply;
import f00f.net.irc.martyr.replies.WhoisIdleReply;
import f00f.net.irc.martyr.replies.WhoisServerReply;
import f00f.net.irc.martyr.replies.WhoisUserReply;

/**
 * CommandRegister is basically a big hashtable that maps IRC
 * identifiers to command objects that can be used as factories to
 * do self-parsing.  CommandRegister is also the central list of
 * commands.
 */
public class CommandRegister
{

private Hashtable commands;
public CommandRegister()
{
	commands = new Hashtable();

	// Note that currently, we only have to register commands that
	// can be received from the server.
	new InviteCommand().selfRegister( this );
	new JoinCommand().selfRegister( this );
	new KickCommand().selfRegister( this );
	new MessageCommand().selfRegister( this );
	new ModeCommand().selfRegister( this );
	new NickCommand().selfRegister( this );
	new NoticeCommand().selfRegister( this );
	new PartCommand().selfRegister( this );
	new PingCommand().selfRegister( this );
	new QuitCommand().selfRegister( this );
	new TopicCommand().selfRegister( this );
	new WelcomeCommand().selfRegister( this );

	// Register errors
	new ChannelBannedError().selfRegister( this );
	new ChannelInviteOnlyError().selfRegister( this );
	new ChannelLimitError().selfRegister( this );
	new ChannelWrongKeyError().selfRegister( this );
	new NickInUseError().selfRegister( this );

	// Register replies
	new ChannelCreationReply().selfRegister( this );
	new LUserClientReply().selfRegister( this );
	new LUserMeReply().selfRegister( this );
	new LUserOpReply().selfRegister( this );
	new ModeReply().selfRegister( this );
	new NamesEndReply().selfRegister( this );
	new NamesReply().selfRegister( this );
	new TopicInfoReply().selfRegister( this );
	new WhoisChannelsReply().selfRegister( this );
	new WhoisEndReply().selfRegister( this );
	new WhoisIdleReply().selfRegister( this );
	new WhoisServerReply().selfRegister( this );
	new WhoisUserReply().selfRegister( this );
}

public void addCommand( String ident, InCommand command )
{
	commands.put( ident, command );
}

public InCommand getCommand( String ident )
{
	return (InCommand)commands.get( ident );
}

}

