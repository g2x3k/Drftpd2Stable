package com.thoughtworks.acceptance.someobjects;

/**
 *
 * 
 * @author <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: Handler.java,v 1.1 2004/03/07 10:26:50 joe Exp $
 */
public class Handler
{
    private Protocol protocol;

    public Protocol getProtocol()
    {
        return protocol;
    }
}
