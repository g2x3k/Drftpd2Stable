package com.thoughtworks.xstream;

import com.thoughtworks.acceptance.objects.OpenSourceSoftware;
import com.thoughtworks.acceptance.objects.SampleLists;
import com.thoughtworks.acceptance.objects.Software;

public class Blah {

    private static long last;

    private static void time(String msg) {
        long now = System.currentTimeMillis();
        if (last == 0) {
            last = now;
        }
        System.out.println((now - last) + " " + msg);
        last = now;
    }

    public static void main(String[] args) {

        time("Starting");
        SampleLists sampleLists = new SampleLists();
        for (int i = 0; i < 1000; i++) {
            sampleLists.bad.add(new Software("aaa", "bbbb"));
            sampleLists.bad.add(new OpenSourceSoftware("aaa", "bbbb", "cccc"));
            sampleLists.bad.add(sampleLists);
        }
        time("Build object");

        XStream xstream = new XStream();
        xstream.alias("sample-lists", SampleLists.class);
        xstream.alias("software", Software.class);
        xstream.alias("oss-software", OpenSourceSoftware.class);
        time("Initialized");

        String xml = xstream.toXML(sampleLists);
        time("Serialized");

        xstream.fromXML(xml);
        time("Deserialized");

    }
}
